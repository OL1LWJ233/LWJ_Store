#ifndef _RELAY_H_
#define _RELAY_H_


#include "stm32f10x.h"

void RELAY_Config(void);
void RELAY_ON(void);
void RELAY_OFF(void);

#endif