#ifndef _LED_H_
#define _LED_H_

#include "stm32f10x.h"


void LED_Config(void);
void LED1_ON(void);
void LED1_OFF(void);
void LED1_TOGGLE(void);
void LED2_ON(void);
void LED2_OFF(void);
void LED2_TOGGLE(void);
void LED3_ON(void);
void LED3_OFF(void);
void LED3_TOGGLE(void);
void LED4_ON(void);
void LED4_OFF(void);
void LED4_TOGGLE(void);
void LED_Show(void);
#endif