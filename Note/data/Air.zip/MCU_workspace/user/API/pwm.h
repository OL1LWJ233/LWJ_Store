#ifndef _PWM_H_
#define _PWM_H_

#include "stm32f10x.h"

void PWM_Config(void);
void Light_Breathe(void);

#endif