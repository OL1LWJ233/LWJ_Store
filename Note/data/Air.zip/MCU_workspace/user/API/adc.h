#ifndef _ADC_H_
#define _ADC_H_

#include "stm32f10x.h"

void ADC_Config(void);
void Get_ADC_Value(void);

extern uint16_t Light_Value;

#endif