#ifndef _UART1_H_
#define _UART1_H_

#include "stm32f10x.h"

void UART1_Config(void);
void UART1_SendByte(uint8_t data);
void UART1_SendBuff(uint8_t * buff,uint16_t length);
void UART1_SendStr(uint8_t * str);
uint8_t UART1_ReceiveByte(void);
void UART1_NVIC_Config(void);
void UART1_Clear_R_Buff(void);

#endif