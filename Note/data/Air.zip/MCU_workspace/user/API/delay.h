#ifndef _DELAY_H_
#define _DELAY_H_

#include "stm32f10x.h"
void Delay_1us(void);
void Delay_us(uint16_t time);
void Delay_ms(uint16_t time);

#endif