#ifndef _DMA_H_
#define _DMA_H_

#include "stm32f10x.h"

extern __IO uint16_t ADCConvertedValue[20];

void ADC_DMA_Config(void);
void Light_Smoke_DataHandle(void);


extern	uint16_t Sum_Avg_Light;
extern	uint16_t Sum_Avg_Smoke;
#endif