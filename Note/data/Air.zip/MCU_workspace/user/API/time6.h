#ifndef _TIME6_H_
#define _TIME6_H_


#include "stm32f10x.h"

extern uint16_t Time6_data;
extern uint16_t Time6_LowPower;


void TIME6_Config(void);

#endif