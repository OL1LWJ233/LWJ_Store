#ifndef _ADCSMOKE_H_
#define _ADCSMOKE_H_

#include "stm32f10x.h"

void ADC_Smoke_Config(void);
void Get_ADC_Smoke_Value(void);
extern uint16_t Smoke_Value;

#endif