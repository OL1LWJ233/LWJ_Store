#ifndef _EXTI_H_
#define _EXTI_H_


#include "stm32f10x.h"
void EXTI_Config(void);

#endif