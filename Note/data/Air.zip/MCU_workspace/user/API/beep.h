#ifndef _BEEP_H_
#define _BEEP_H_


#include "stm32f10x.h"

void BEEP_Config(void);
void BEEP_ON(void);
void BEEP_OFF(void);

#endif