#ifndef _RTC_H_
#define _RTC_H_

#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"



extern struct tm *Now_Time;
extern uint32_t Now_Time_Cnt;
extern uint8_t Sencond_Flag;  //���־


void RTC_Config(void);
void RTC_NVIC_SecConfig(void);
void RTC_NVIC_AlrConfig(void);
	
#endif