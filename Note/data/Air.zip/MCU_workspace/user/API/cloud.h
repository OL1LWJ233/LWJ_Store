#ifndef _CLOUD_H_
#define _CLOUD_H_

#include "stm32f10x.h"

#define Client_ID "k0djb2JKUpE.Device_205|securemode=2,signmethod=hmacsha256,timestamp=1698234808755|"
#define Username	"Device_205&k0djb2JKUpE"
#define Passwd	"09c67ea2aeae9e8e34fe9e0c5df6e7aaaba205b68496fc58061dc06cab6f61b3"

#define Topic_Publish "/sys/k0djb2JKUpE/Device_205/thing/event/property/post"
#define Topic_Subscribe "/sys/k0djb2JKUpE/Device_205/thing/service/property/set"


extern uint16_t Publish_Time[2];
extern uint16_t Heart_Time[2];


#define WifiName_Addr_Begin	0x410000					//Wifi�˺Ŵ�flash��0x280000+0x190000=0x410000��ʼд
#define WifiPswd_Addr_Begin	0x430000					//Wifi�����flash��0x430000��ʼд

#define Wifi_Addr_Begin	0x450000

void MQTT_Connect(void);
void MQTT_Publish(void);
void MQTT_Subscribe(void);
void MQTT_Ping(void);

void WifiConnect_Init(void);


#endif