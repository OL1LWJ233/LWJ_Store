#ifndef __SPI_H_
#define __SPI_H_

#include "stm32f10x.h"

void SPI_Config(void);
uint8_t SPI_Rec_Send(uint8_t date);

#endif

