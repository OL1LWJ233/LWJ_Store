#ifndef _KEY_H_
#define _KEY_H_

#include "stm32f10x.h"

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "event_groups.h"


void KEY_Config(void);
uint8_t KEY_GET_Value(void);
void KEY_Handle(void);

#endif