#ifndef _DHT11_H_
#define _DHT11_H_

#include "stm32f10x.h"

void DHT11_Config(void);
uint8_t DHT11_Get_Value(void);

extern float Tem;
extern uint8_t Hum;

#endif