/*
 * Copyright 2023 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
//#include "custom.h"


void setup_scr_screen_1(lv_ui *ui){

	//Write codes screen_1
	ui->screen_1 = lv_obj_create(NULL, NULL);

	//Write style LV_OBJ_PART_MAIN for screen_1
	static lv_style_t style_screen_1_main;
	lv_style_reset(&style_screen_1_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_main
	lv_style_set_bg_color(&style_screen_1_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0xe1, 0xff));
	lv_style_set_bg_opa(&style_screen_1_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_1, LV_OBJ_PART_MAIN, &style_screen_1_main);

	//Write codes screen_1_kun
	ui->screen_1_kun = lv_img_create(ui->screen_1, NULL);

	//Write style LV_IMG_PART_MAIN for screen_1_kun
	static lv_style_t style_screen_1_kun_main;
	lv_style_reset(&style_screen_1_kun_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_kun_main
	lv_style_set_image_recolor(&style_screen_1_kun_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_1_kun_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_1_kun_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_1_kun, LV_IMG_PART_MAIN, &style_screen_1_kun_main);
	lv_obj_set_pos(ui->screen_1_kun, 0, 0);
	lv_obj_set_size(ui->screen_1_kun, 60, 60);
	lv_obj_set_click(ui->screen_1_kun, true);
	lv_img_set_src(ui->screen_1_kun,&_ikun_alpha_60x60);
	lv_img_set_pivot(ui->screen_1_kun, 0,0);
	lv_img_set_angle(ui->screen_1_kun, 0);

	//Write codes screen_1_tem
	ui->screen_1_tem = lv_label_create(ui->screen_1, NULL);
	lv_label_set_text(ui->screen_1_tem, "25");
	lv_label_set_long_mode(ui->screen_1_tem, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_tem, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_tem
	static lv_style_t style_screen_1_tem_main;
	lv_style_reset(&style_screen_1_tem_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_tem_main
	lv_style_set_radius(&style_screen_1_tem_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_tem_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_tem_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_tem_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_tem_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_tem_main, LV_STATE_DEFAULT, lv_color_make(0x52, 0x00, 0xcc));
	lv_style_set_text_font(&style_screen_1_tem_main, LV_STATE_DEFAULT, &lv_font_simsun_25);
	lv_style_set_text_letter_space(&style_screen_1_tem_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_tem_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_tem_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_tem_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_tem_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_tem, LV_LABEL_PART_MAIN, &style_screen_1_tem_main);
	lv_obj_set_pos(ui->screen_1_tem, 64, 18);
	lv_obj_set_size(ui->screen_1_tem, 40, 0);

	//Write codes screen_1_label_1
	ui->screen_1_label_1 = lv_label_create(ui->screen_1, NULL);
	lv_label_set_text(ui->screen_1_label_1, "℃ ");
	lv_label_set_long_mode(ui->screen_1_label_1, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_1, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_1
	static lv_style_t style_screen_1_label_1_main;
	lv_style_reset(&style_screen_1_label_1_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_1_main
	lv_style_set_radius(&style_screen_1_label_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_1_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_1_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_1_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_1_main, LV_STATE_DEFAULT, lv_color_make(0x52, 0x00, 0xcc));
	lv_style_set_text_font(&style_screen_1_label_1_main, LV_STATE_DEFAULT, &lv_font_simsun_25);
	lv_style_set_text_letter_space(&style_screen_1_label_1_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_1_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_1, LV_LABEL_PART_MAIN, &style_screen_1_label_1_main);
	lv_obj_set_pos(ui->screen_1_label_1, 90, 18);
	lv_obj_set_size(ui->screen_1_label_1, 40, 0);

	//Write codes screen_1_label_2
	ui->screen_1_label_2 = lv_label_create(ui->screen_1, NULL);
	lv_label_set_text(ui->screen_1_label_2, "湿度 ");
	lv_label_set_long_mode(ui->screen_1_label_2, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_2, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_2
	static lv_style_t style_screen_1_label_2_main;
	lv_style_reset(&style_screen_1_label_2_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_2_main
	lv_style_set_radius(&style_screen_1_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_2_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_2_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_2_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_2_main, LV_STATE_DEFAULT, lv_color_make(0xf4, 0x52, 0xd9));
	lv_style_set_text_font(&style_screen_1_label_2_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_2_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_2_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_2, LV_LABEL_PART_MAIN, &style_screen_1_label_2_main);
	lv_obj_set_pos(ui->screen_1_label_2, 9, 85);
	lv_obj_set_size(ui->screen_1_label_2, 50, 0);

	//Write codes screen_1_label_3
	ui->screen_1_label_3 = lv_label_create(ui->screen_1, NULL);
	lv_label_set_text(ui->screen_1_label_3, "10");
	lv_label_set_long_mode(ui->screen_1_label_3, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_3, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_3
	static lv_style_t style_screen_1_label_3_main;
	lv_style_reset(&style_screen_1_label_3_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_3_main
	lv_style_set_radius(&style_screen_1_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_3_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_3_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_3_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_3_main, LV_STATE_DEFAULT, lv_color_make(0xf5, 0x8e, 0x8e));
	lv_style_set_text_font(&style_screen_1_label_3_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_3_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_3_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_3, LV_LABEL_PART_MAIN, &style_screen_1_label_3_main);
	lv_obj_set_pos(ui->screen_1_label_3, 50, 85);
	lv_obj_set_size(ui->screen_1_label_3, 50, 0);

	//Write codes screen_1_label_4
	ui->screen_1_label_4 = lv_label_create(ui->screen_1, NULL);
	lv_label_set_text(ui->screen_1_label_4, "%RH");
	lv_label_set_long_mode(ui->screen_1_label_4, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_4, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_4
	static lv_style_t style_screen_1_label_4_main;
	lv_style_reset(&style_screen_1_label_4_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_4_main
	lv_style_set_radius(&style_screen_1_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_4_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_4_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_4_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_4_main, LV_STATE_DEFAULT, lv_color_make(0xfa, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_1_label_4_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_4_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_4_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_4, LV_LABEL_PART_MAIN, &style_screen_1_label_4_main);
	lv_obj_set_pos(ui->screen_1_label_4, 74, 85);
	lv_obj_set_size(ui->screen_1_label_4, 50, 0);

	//Write codes screen_1_c2ho
	ui->screen_1_c2ho = lv_label_create(ui->screen_1, NULL);
	lv_label_set_text(ui->screen_1_c2ho, "甲醛 ");
	lv_label_set_long_mode(ui->screen_1_c2ho, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_c2ho, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_c2ho
	static lv_style_t style_screen_1_c2ho_main;
	lv_style_reset(&style_screen_1_c2ho_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_c2ho_main
	lv_style_set_radius(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_c2ho_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_c2ho, LV_LABEL_PART_MAIN, &style_screen_1_c2ho_main);
	lv_obj_set_pos(ui->screen_1_c2ho, 9, 115);
	lv_obj_set_size(ui->screen_1_c2ho, 50, 0);

	//Write codes screen_1_time
	ui->screen_1_time = lv_label_create(ui->screen_1, NULL);
	lv_label_set_text(ui->screen_1_time, "2023/11/6   11：11：11 ");
	lv_label_set_long_mode(ui->screen_1_time, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_time, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_time
	static lv_style_t style_screen_1_time_main;
	lv_style_reset(&style_screen_1_time_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_time_main
	lv_style_set_radius(&style_screen_1_time_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_time_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_time_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_time_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_time_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_time_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x05, 0x94));
	lv_style_set_text_font(&style_screen_1_time_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_time_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_time_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_time_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_time_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_time_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_time, LV_LABEL_PART_MAIN, &style_screen_1_time_main);
	lv_obj_set_pos(ui->screen_1_time, 12, 146);
	lv_obj_set_size(ui->screen_1_time, 90, 0);

	//Write codes screen_1_cont
	ui->screen_1_cont = lv_cont_create(ui->screen_1, NULL);

	//Write style LV_CONT_PART_MAIN for screen_1_cont
	static lv_style_t style_screen_1_cont_main;
	lv_style_reset(&style_screen_1_cont_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_cont_main
	lv_style_set_radius(&style_screen_1_cont_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_cont_main, LV_STATE_DEFAULT, lv_color_make(0xfb, 0xa7, 0xe0));
	lv_style_set_bg_grad_color(&style_screen_1_cont_main, LV_STATE_DEFAULT, lv_color_make(0xf2, 0xa1, 0xd8));
	lv_style_set_bg_grad_dir(&style_screen_1_cont_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_cont_main, LV_STATE_DEFAULT, 0);
	lv_style_set_border_color(&style_screen_1_cont_main, LV_STATE_DEFAULT, lv_color_make(0x99, 0x99, 0x99));
	lv_style_set_border_width(&style_screen_1_cont_main, LV_STATE_DEFAULT, 1);
	lv_style_set_border_opa(&style_screen_1_cont_main, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_1_cont_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_cont_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_cont_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_cont_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_cont, LV_CONT_PART_MAIN, &style_screen_1_cont_main);
	lv_obj_set_pos(ui->screen_1_cont, 220, 0);
	lv_obj_set_size(ui->screen_1_cont, 100, 100);
	lv_obj_set_click(ui->screen_1_cont, false);

	//Write codes screen_1_label_5
	ui->screen_1_label_5 = lv_label_create(ui->screen_1_cont, NULL);
	lv_label_set_text(ui->screen_1_label_5, "VOC");
	lv_label_set_long_mode(ui->screen_1_label_5, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_5, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_5
	static lv_style_t style_screen_1_label_5_main;
	lv_style_reset(&style_screen_1_label_5_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_5_main
	lv_style_set_radius(&style_screen_1_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_5_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_5_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_5_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_5_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_1_label_5_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_5_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_5_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_5, LV_LABEL_PART_MAIN, &style_screen_1_label_5_main);
	lv_obj_set_pos(ui->screen_1_label_5, 4, 9);
	lv_obj_set_size(ui->screen_1_label_5, 40, 0);

	//Write codes screen_1_label_8
	ui->screen_1_label_8 = lv_label_create(ui->screen_1_cont, NULL);
	lv_label_set_text(ui->screen_1_label_8, "32");
	lv_label_set_long_mode(ui->screen_1_label_8, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_8, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_8
	static lv_style_t style_screen_1_label_8_main;
	lv_style_reset(&style_screen_1_label_8_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_8_main
	lv_style_set_radius(&style_screen_1_label_8_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_8_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_8_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_8_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_8_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_8_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_1_label_8_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_8_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_8_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_8_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_8_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_8_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_8, LV_LABEL_PART_MAIN, &style_screen_1_label_8_main);
	lv_obj_set_pos(ui->screen_1_label_8, 50, 8);
	lv_obj_set_size(ui->screen_1_label_8, 40, 0);

	//Write codes screen_1_label_9
	ui->screen_1_label_9 = lv_label_create(ui->screen_1_cont, NULL);
	lv_label_set_text(ui->screen_1_label_9, "3208");
	lv_label_set_long_mode(ui->screen_1_label_9, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_9, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_9
	static lv_style_t style_screen_1_label_9_main;
	lv_style_reset(&style_screen_1_label_9_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_9_main
	lv_style_set_radius(&style_screen_1_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_9_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_9_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_9_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_9_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_1_label_9_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_9_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_9_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_9, LV_LABEL_PART_MAIN, &style_screen_1_label_9_main);
	lv_obj_set_pos(ui->screen_1_label_9, 50, 29);
	lv_obj_set_size(ui->screen_1_label_9, 40, 0);

	//Write codes screen_1_label_10
	ui->screen_1_label_10 = lv_label_create(ui->screen_1_cont, NULL);
	lv_label_set_text(ui->screen_1_label_10, "3208");
	lv_label_set_long_mode(ui->screen_1_label_10, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_10, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_10
	static lv_style_t style_screen_1_label_10_main;
	lv_style_reset(&style_screen_1_label_10_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_10_main
	lv_style_set_radius(&style_screen_1_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_10_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_10_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_10_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_10_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_1_label_10_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_10_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_10_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_10, LV_LABEL_PART_MAIN, &style_screen_1_label_10_main);
	lv_obj_set_pos(ui->screen_1_label_10, 50, 48);
	lv_obj_set_size(ui->screen_1_label_10, 40, 0);

	//Write codes screen_1_label_6
	ui->screen_1_label_6 = lv_label_create(ui->screen_1_cont, NULL);
	lv_label_set_text(ui->screen_1_label_6, "LIGHT");
	lv_label_set_long_mode(ui->screen_1_label_6, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_6, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_6
	static lv_style_t style_screen_1_label_6_main;
	lv_style_reset(&style_screen_1_label_6_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_6_main
	lv_style_set_radius(&style_screen_1_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_6_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_6_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_6_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_6_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_1_label_6_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_6_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_6_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_6, LV_LABEL_PART_MAIN, &style_screen_1_label_6_main);
	lv_obj_set_pos(ui->screen_1_label_6, 4, 29);
	lv_obj_set_size(ui->screen_1_label_6, 40, 0);

	//Write codes screen_1_label_7
	ui->screen_1_label_7 = lv_label_create(ui->screen_1_cont, NULL);
	lv_label_set_text(ui->screen_1_label_7, "Smoke");
	lv_label_set_long_mode(ui->screen_1_label_7, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_1_label_7, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_1_label_7
	static lv_style_t style_screen_1_label_7_main;
	lv_style_reset(&style_screen_1_label_7_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_1_label_7_main
	lv_style_set_radius(&style_screen_1_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_1_label_7_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_1_label_7_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_1_label_7_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_1_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_1_label_7_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_1_label_7_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_1_label_7_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_1_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_1_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_1_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_1_label_7_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_1_label_7, LV_LABEL_PART_MAIN, &style_screen_1_label_7_main);
	lv_obj_set_pos(ui->screen_1_label_7, 4, 48);
	lv_obj_set_size(ui->screen_1_label_7, 40, 0);
	lv_cont_set_layout(ui->screen_1_cont, LV_LAYOUT_OFF);
	lv_cont_set_fit(ui->screen_1_cont, LV_FIT_NONE);
}
