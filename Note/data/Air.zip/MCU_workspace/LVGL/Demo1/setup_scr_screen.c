/*
 * Copyright 2023 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
//#include "custom.h"



void setup_scr_screen(lv_ui *ui){

	//Write codes screen
	ui->screen = lv_obj_create(NULL, NULL);

	//Write style LV_OBJ_PART_MAIN for screen
	static lv_style_t style_screen_main;
	lv_style_reset(&style_screen_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_main
	lv_style_set_bg_color(&style_screen_main, LV_STATE_DEFAULT, lv_color_make(0x3a, 0x00, 0x61));
	lv_style_set_bg_opa(&style_screen_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen, LV_OBJ_PART_MAIN, &style_screen_main);

	//Write codes screen_start
	ui->screen_start = lv_bar_create(ui->screen, NULL);

	//Write style LV_BAR_PART_BG for screen_start
	static lv_style_t style_screen_start_bg;
	lv_style_reset(&style_screen_start_bg);

	//Write style state: LV_STATE_DEFAULT for style_screen_start_bg
	lv_style_set_radius(&style_screen_start_bg, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_start_bg, LV_STATE_DEFAULT, lv_color_make(0xa8, 0xfe, 0xff));
	lv_style_set_bg_grad_color(&style_screen_start_bg, LV_STATE_DEFAULT, lv_color_make(0xb9, 0xfd, 0xa0));
	lv_style_set_bg_grad_dir(&style_screen_start_bg, LV_STATE_DEFAULT, LV_GRAD_DIR_HOR);
	lv_style_set_bg_opa(&style_screen_start_bg, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_start_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_start_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_start_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_start_bg, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_start, LV_BAR_PART_BG, &style_screen_start_bg);

	//Write style LV_BAR_PART_INDIC for screen_start
	static lv_style_t style_screen_start_indic;
	lv_style_reset(&style_screen_start_indic);

	//Write style state: LV_STATE_DEFAULT for style_screen_start_indic
	lv_style_set_radius(&style_screen_start_indic, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_start_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_start_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_dir(&style_screen_start_indic, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_start_indic, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_start, LV_BAR_PART_INDIC, &style_screen_start_indic);
	lv_obj_set_pos(ui->screen_start, 115, 103);
	lv_obj_set_size(ui->screen_start, 90, 20);
	lv_bar_set_anim_time(ui->screen_start,1000);
	lv_bar_set_value(ui->screen_start,25,LV_ANIM_OFF);
	lv_bar_set_range(ui->screen_start,0,100);
}
