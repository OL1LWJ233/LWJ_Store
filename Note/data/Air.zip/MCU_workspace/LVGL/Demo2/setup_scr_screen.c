/*
 * Copyright 2023 NXP
 * SPDX-License-Identifier: MIT
 */

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
//#include "custom.h"


void setup_scr_screen(lv_ui *ui){

	//Write codes screen
	ui->screen = lv_obj_create(NULL, NULL);

	//Write style LV_OBJ_PART_MAIN for screen
	static lv_style_t style_screen_main;
	lv_style_reset(&style_screen_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_main
	lv_style_set_bg_color(&style_screen_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_opa(&style_screen_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen, LV_OBJ_PART_MAIN, &style_screen_main);

	//Write codes screen_cont_1
	ui->screen_cont_1 = lv_cont_create(ui->screen, NULL);

	//Write style LV_CONT_PART_MAIN for screen_cont_1
	static lv_style_t style_screen_cont_1_main;
	lv_style_reset(&style_screen_cont_1_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_cont_1_main
	lv_style_set_radius(&style_screen_cont_1_main, LV_STATE_DEFAULT, 5);
	lv_style_set_bg_color(&style_screen_cont_1_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_cont_1_main, LV_STATE_DEFAULT, lv_color_make(0xbf, 0xfd, 0xfc));
	lv_style_set_bg_grad_dir(&style_screen_cont_1_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_cont_1_main, LV_STATE_DEFAULT, 255);
	lv_style_set_border_color(&style_screen_cont_1_main, LV_STATE_DEFAULT, lv_color_make(0xa4, 0xbc, 0xf4));
	lv_style_set_border_width(&style_screen_cont_1_main, LV_STATE_DEFAULT, 3);
	lv_style_set_border_opa(&style_screen_cont_1_main, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_cont_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_cont_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_cont_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_cont_1_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_cont_1, LV_CONT_PART_MAIN, &style_screen_cont_1_main);
	lv_obj_set_pos(ui->screen_cont_1, 0, 0);
	lv_obj_set_size(ui->screen_cont_1, 120, 100);
	lv_obj_set_click(ui->screen_cont_1, false);

	//Write codes screen_label_26
	ui->screen_label_26 = lv_label_create(ui->screen_cont_1, NULL);
	lv_label_set_text(ui->screen_label_26, "kunkun检测仪 ");
	lv_label_set_long_mode(ui->screen_label_26, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_26, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_26
	static lv_style_t style_screen_label_26_main;
	lv_style_reset(&style_screen_label_26_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_26_main
	lv_style_set_radius(&style_screen_label_26_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_26_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_26_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_26_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_26_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_26_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_26_main, LV_STATE_DEFAULT, &lv_font_simsun_14);
	lv_style_set_text_letter_space(&style_screen_label_26_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_26_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_26_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_26_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_26_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_26, LV_LABEL_PART_MAIN, &style_screen_label_26_main);
	lv_obj_set_pos(ui->screen_label_26, 10, 60);
	lv_obj_set_size(ui->screen_label_26, 100, 0);

	//Write codes screen_img_16
	ui->screen_img_16 = lv_img_create(ui->screen_cont_1, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_16
	static lv_style_t style_screen_img_16_main;
	lv_style_reset(&style_screen_img_16_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_16_main
	lv_style_set_image_recolor(&style_screen_img_16_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_16_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_16_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_16, LV_IMG_PART_MAIN, &style_screen_img_16_main);
	lv_obj_set_pos(ui->screen_img_16, 75, 15);
	lv_obj_set_size(ui->screen_img_16, 35, 35);
	lv_obj_set_click(ui->screen_img_16, true);
	lv_img_set_src(ui->screen_img_16,&_sun_alpha_35x35);
	lv_img_set_pivot(ui->screen_img_16, 0,0);
	lv_img_set_angle(ui->screen_img_16, 0);

	//Write codes screen_label_25
	ui->screen_label_25 = lv_label_create(ui->screen_cont_1, NULL);
	lv_label_set_text(ui->screen_label_25, "iPhone Nova11se");
	lv_label_set_long_mode(ui->screen_label_25, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_25, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_25
	static lv_style_t style_screen_label_25_main;
	lv_style_reset(&style_screen_label_25_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_25_main
	lv_style_set_radius(&style_screen_label_25_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_25_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_25_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_25_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_25_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_25_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_25_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_25_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_left(&style_screen_label_25_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_25_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_25_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_25_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_25, LV_LABEL_PART_MAIN, &style_screen_label_25_main);
	lv_obj_set_pos(ui->screen_label_25, 10, 85);
	lv_obj_set_size(ui->screen_label_25, 100, 0);

	//Write codes screen_img_15
	ui->screen_img_15 = lv_img_create(ui->screen_cont_1, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_15
	static lv_style_t style_screen_img_15_main;
	lv_style_reset(&style_screen_img_15_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_15_main
	lv_style_set_image_recolor(&style_screen_img_15_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_15_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_15_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_15, LV_IMG_PART_MAIN, &style_screen_img_15_main);
	lv_obj_set_pos(ui->screen_img_15, 7, 84);
	lv_obj_set_size(ui->screen_img_15, 10, 10);
	lv_obj_set_click(ui->screen_img_15, true);
	lv_img_set_src(ui->screen_img_15,&_iphone_alpha_10x10);
	lv_img_set_pivot(ui->screen_img_15, 0,0);
	lv_img_set_angle(ui->screen_img_15, 0);

	//Write codes screen_img_4
	ui->screen_img_4 = lv_img_create(ui->screen_cont_1, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_4
	static lv_style_t style_screen_img_4_main;
	lv_style_reset(&style_screen_img_4_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_4_main
	lv_style_set_image_recolor(&style_screen_img_4_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_4_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_4, LV_IMG_PART_MAIN, &style_screen_img_4_main);
	lv_obj_set_pos(ui->screen_img_4, 35, 30);
	lv_obj_set_size(ui->screen_img_4, 7, 7);
	lv_obj_set_click(ui->screen_img_4, true);
	lv_img_set_src(ui->screen_img_4,&_ID_alpha_7x7);
	lv_img_set_pivot(ui->screen_img_4, 0,0);
	lv_img_set_angle(ui->screen_img_4, 0);

	//Write codes screen_img_3
	ui->screen_img_3 = lv_img_create(ui->screen_cont_1, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_3
	static lv_style_t style_screen_img_3_main;
	lv_style_reset(&style_screen_img_3_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_3_main
	lv_style_set_image_recolor(&style_screen_img_3_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_3_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_3, LV_IMG_PART_MAIN, &style_screen_img_3_main);
	lv_obj_set_pos(ui->screen_img_3, 30, 18);
	lv_obj_set_size(ui->screen_img_3, 30, 10);
	lv_obj_set_click(ui->screen_img_3, true);
	lv_img_set_src(ui->screen_img_3,&_VIP5_alpha_30x10);
	lv_img_set_pivot(ui->screen_img_3, 0,0);
	lv_img_set_angle(ui->screen_img_3, 0);

	//Write codes screen_img_2
	ui->screen_img_2 = lv_img_create(ui->screen_cont_1, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_2
	static lv_style_t style_screen_img_2_main;
	lv_style_reset(&style_screen_img_2_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_2_main
	lv_style_set_image_recolor(&style_screen_img_2_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_2_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_2, LV_IMG_PART_MAIN, &style_screen_img_2_main);
	lv_obj_set_pos(ui->screen_img_2, 6, 12);
	lv_obj_set_size(ui->screen_img_2, 20, 20);
	lv_obj_set_click(ui->screen_img_2, true);
	lv_img_set_src(ui->screen_img_2,&_zf_alpha_20x20);
	lv_img_set_pivot(ui->screen_img_2, 0,0);
	lv_img_set_angle(ui->screen_img_2, 0);

	//Write codes screen_img_1
	ui->screen_img_1 = lv_img_create(ui->screen_cont_1, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_1
	static lv_style_t style_screen_img_1_main;
	lv_style_reset(&style_screen_img_1_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_1_main
	lv_style_set_image_recolor(&style_screen_img_1_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_1_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_1_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_1, LV_IMG_PART_MAIN, &style_screen_img_1_main);
	lv_obj_set_pos(ui->screen_img_1, 8, 22);
	lv_obj_set_size(ui->screen_img_1, 17, 17);
	lv_obj_set_click(ui->screen_img_1, true);
	lv_img_set_src(ui->screen_img_1,&_QQ_alpha_17x17);
	lv_img_set_pivot(ui->screen_img_1, 0,0);
	lv_img_set_angle(ui->screen_img_1, 0);
	lv_cont_set_layout(ui->screen_cont_1, LV_LAYOUT_OFF);
	lv_cont_set_fit(ui->screen_cont_1, LV_FIT_NONE);

	//Write codes screen_cont_2
	ui->screen_cont_2 = lv_cont_create(ui->screen, NULL);

	//Write style LV_CONT_PART_MAIN for screen_cont_2
	static lv_style_t style_screen_cont_2_main;
	lv_style_reset(&style_screen_cont_2_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_cont_2_main
	lv_style_set_radius(&style_screen_cont_2_main, LV_STATE_DEFAULT, 5);
	lv_style_set_bg_color(&style_screen_cont_2_main, LV_STATE_DEFAULT, lv_color_make(0xcc, 0xfe, 0xff));
	lv_style_set_bg_grad_color(&style_screen_cont_2_main, LV_STATE_DEFAULT, lv_color_make(0xc1, 0xfb, 0xe5));
	lv_style_set_bg_grad_dir(&style_screen_cont_2_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_cont_2_main, LV_STATE_DEFAULT, 255);
	lv_style_set_border_color(&style_screen_cont_2_main, LV_STATE_DEFAULT, lv_color_make(0xa4, 0xbc, 0xf4));
	lv_style_set_border_width(&style_screen_cont_2_main, LV_STATE_DEFAULT, 3);
	lv_style_set_border_opa(&style_screen_cont_2_main, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_cont_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_cont_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_cont_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_cont_2_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_cont_2, LV_CONT_PART_MAIN, &style_screen_cont_2_main);
	lv_obj_set_pos(ui->screen_cont_2, 0, 100);
	lv_obj_set_size(ui->screen_cont_2, 200, 140);
	lv_obj_set_click(ui->screen_cont_2, false);

	//Write codes screen_img_11
	ui->screen_img_11 = lv_img_create(ui->screen_cont_2, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_11
	static lv_style_t style_screen_img_11_main;
	lv_style_reset(&style_screen_img_11_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_11_main
	lv_style_set_image_recolor(&style_screen_img_11_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_11_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_11_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_11, LV_IMG_PART_MAIN, &style_screen_img_11_main);
	lv_obj_set_pos(ui->screen_img_11, 10, 100);
	lv_obj_set_size(ui->screen_img_11, 20, 20);
	lv_obj_set_click(ui->screen_img_11, true);
	lv_img_set_src(ui->screen_img_11,&_light_alpha_20x20);
	lv_img_set_pivot(ui->screen_img_11, 0,0);
	lv_img_set_angle(ui->screen_img_11, 0);

	//Write codes screen_label_6
	ui->screen_label_6 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_6, "温度 ");
	lv_label_set_long_mode(ui->screen_label_6, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_6, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_6
	static lv_style_t style_screen_label_6_main;
	lv_style_reset(&style_screen_label_6_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_6_main
	lv_style_set_radius(&style_screen_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_6_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_6_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_6_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_6_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_6_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_6_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_6_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_6, LV_LABEL_PART_MAIN, &style_screen_label_6_main);
	lv_obj_set_pos(ui->screen_label_6, 6, 35);
	lv_obj_set_size(ui->screen_label_6, 30, 0);

	//Write codes screen_label_13
	ui->screen_label_13 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_13, "25.5");
	lv_label_set_long_mode(ui->screen_label_13, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_13, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_13
	static lv_style_t style_screen_label_13_main;
	lv_style_reset(&style_screen_label_13_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_13_main
	lv_style_set_radius(&style_screen_label_13_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_13_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_13_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_13_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_13_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_13_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_13_main, LV_STATE_DEFAULT, &lv_font_simsun_20);
	lv_style_set_text_letter_space(&style_screen_label_13_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_left(&style_screen_label_13_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_13_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_13_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_13_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_13, LV_LABEL_PART_MAIN, &style_screen_label_13_main);
	lv_obj_set_pos(ui->screen_label_13, 45, 11);
	lv_obj_set_size(ui->screen_label_13, 40, 0);

	//Write codes screen_label_14
	ui->screen_label_14 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_14, "℃ ");
	lv_label_set_long_mode(ui->screen_label_14, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_14, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_14
	static lv_style_t style_screen_label_14_main;
	lv_style_reset(&style_screen_label_14_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_14_main
	lv_style_set_radius(&style_screen_label_14_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_14_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_14_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_14_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_14_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_14_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_14_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_label_14_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_14_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_14_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_14_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_14_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_14, LV_LABEL_PART_MAIN, &style_screen_label_14_main);
	lv_obj_set_pos(ui->screen_label_14, 79, 13);
	lv_obj_set_size(ui->screen_label_14, 30, 0);

	//Write codes screen_label_9
	ui->screen_label_9 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_9, "CO₂ ");
	lv_label_set_long_mode(ui->screen_label_9, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_9, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_9
	static lv_style_t style_screen_label_9_main;
	lv_style_reset(&style_screen_label_9_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_9_main
	lv_style_set_radius(&style_screen_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_9_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_9_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_9_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_9_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_9_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_9_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_9_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_9, LV_LABEL_PART_MAIN, &style_screen_label_9_main);
	lv_obj_set_pos(ui->screen_label_9, 118, 34);
	lv_obj_set_size(ui->screen_label_9, 30, 0);

	//Write codes screen_label_10
	ui->screen_label_10 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_10, "VOC");
	lv_label_set_long_mode(ui->screen_label_10, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_10, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_10
	static lv_style_t style_screen_label_10_main;
	lv_style_reset(&style_screen_label_10_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_10_main
	lv_style_set_radius(&style_screen_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_10_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_10_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_10_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_10_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_10_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_10_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_10_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_10, LV_LABEL_PART_MAIN, &style_screen_label_10_main);
	lv_obj_set_pos(ui->screen_label_10, 115, 80);
	lv_obj_set_size(ui->screen_label_10, 30, 0);

	//Write codes screen_label_11
	ui->screen_label_11 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_11, "烟雾 ");
	lv_label_set_long_mode(ui->screen_label_11, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_11, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_11
	static lv_style_t style_screen_label_11_main;
	lv_style_reset(&style_screen_label_11_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_11_main
	lv_style_set_radius(&style_screen_label_11_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_11_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_11_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_11_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_11_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_11_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_11_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_11_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_11_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_11_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_11_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_11_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_11, LV_LABEL_PART_MAIN, &style_screen_label_11_main);
	lv_obj_set_pos(ui->screen_label_11, 115, 120);
	lv_obj_set_size(ui->screen_label_11, 30, 0);

	//Write codes screen_label_7
	ui->screen_label_7 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_7, "湿度 ");
	lv_label_set_long_mode(ui->screen_label_7, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_7, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_7
	static lv_style_t style_screen_label_7_main;
	lv_style_reset(&style_screen_label_7_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_7_main
	lv_style_set_radius(&style_screen_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_7_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_7_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_7_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_7_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_7_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_7_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_7_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_7_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_7, LV_LABEL_PART_MAIN, &style_screen_label_7_main);
	lv_obj_set_pos(ui->screen_label_7, 6, 80);
	lv_obj_set_size(ui->screen_label_7, 30, 0);

	//Write codes screen_label_15
	ui->screen_label_15 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_15, "30 ");
	lv_label_set_long_mode(ui->screen_label_15, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_15, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_15
	static lv_style_t style_screen_label_15_main;
	lv_style_reset(&style_screen_label_15_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_15_main
	lv_style_set_radius(&style_screen_label_15_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_15_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_15_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_15_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_15_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_15_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_15_main, LV_STATE_DEFAULT, &lv_font_simsun_20);
	lv_style_set_text_letter_space(&style_screen_label_15_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_15_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_15_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_15_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_15_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_15, LV_LABEL_PART_MAIN, &style_screen_label_15_main);
	lv_obj_set_pos(ui->screen_label_15, 45, 57);
	lv_obj_set_size(ui->screen_label_15, 30, 0);

	//Write codes screen_label_17
	ui->screen_label_17 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_17, "3208");
	lv_label_set_long_mode(ui->screen_label_17, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_17, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_17
	static lv_style_t style_screen_label_17_main;
	lv_style_reset(&style_screen_label_17_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_17_main
	lv_style_set_radius(&style_screen_label_17_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_17_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_17_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_17_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_17_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_17_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_17_main, LV_STATE_DEFAULT, &lv_font_simsun_20);
	lv_style_set_text_letter_space(&style_screen_label_17_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_17_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_17_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_17_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_17_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_17, LV_LABEL_PART_MAIN, &style_screen_label_17_main);
	lv_obj_set_pos(ui->screen_label_17, 43, 100);
	lv_obj_set_size(ui->screen_label_17, 46, 0);

	//Write codes screen_label_18
	ui->screen_label_18 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_18, "30");
	lv_label_set_long_mode(ui->screen_label_18, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_18, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_18
	static lv_style_t style_screen_label_18_main;
	lv_style_reset(&style_screen_label_18_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_18_main
	lv_style_set_radius(&style_screen_label_18_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_18_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_18_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_18_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_18_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_18_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_18_main, LV_STATE_DEFAULT, &lv_font_simsun_20);
	lv_style_set_text_letter_space(&style_screen_label_18_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_left(&style_screen_label_18_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_18_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_18_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_18_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_18, LV_LABEL_PART_MAIN, &style_screen_label_18_main);
	lv_obj_set_pos(ui->screen_label_18, 145, 100);
	lv_obj_set_size(ui->screen_label_18, 46, 0);

	//Write codes screen_label_19
	ui->screen_label_19 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_19, "30");
	lv_label_set_long_mode(ui->screen_label_19, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_19, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_19
	static lv_style_t style_screen_label_19_main;
	lv_style_reset(&style_screen_label_19_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_19_main
	lv_style_set_radius(&style_screen_label_19_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_19_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_19_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_19_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_19_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_19_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_19_main, LV_STATE_DEFAULT, &lv_font_simsun_20);
	lv_style_set_text_letter_space(&style_screen_label_19_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_19_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_19_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_19_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_19_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_19, LV_LABEL_PART_MAIN, &style_screen_label_19_main);
	lv_obj_set_pos(ui->screen_label_19, 145, 57);
	lv_obj_set_size(ui->screen_label_19, 46, 0);

	//Write codes screen_label_20
	ui->screen_label_20 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_20, "300");
	lv_label_set_long_mode(ui->screen_label_20, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_20, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_20
	static lv_style_t style_screen_label_20_main;
	lv_style_reset(&style_screen_label_20_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_20_main
	lv_style_set_radius(&style_screen_label_20_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_20_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_20_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_20_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_20_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_20_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_20_main, LV_STATE_DEFAULT, &lv_font_simsun_20);
	lv_style_set_text_letter_space(&style_screen_label_20_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_20_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_20_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_20_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_20_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_20, LV_LABEL_PART_MAIN, &style_screen_label_20_main);
	lv_obj_set_pos(ui->screen_label_20, 155, 12);
	lv_obj_set_size(ui->screen_label_20, 35, 0);

	//Write codes screen_label_16
	ui->screen_label_16 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_16, "%RH");
	lv_label_set_long_mode(ui->screen_label_16, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_16, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_16
	static lv_style_t style_screen_label_16_main;
	lv_style_reset(&style_screen_label_16_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_16_main
	lv_style_set_radius(&style_screen_label_16_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_16_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_16_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_16_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_16_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_16_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_16_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_label_16_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_16_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_16_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_16_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_16_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_16, LV_LABEL_PART_MAIN, &style_screen_label_16_main);
	lv_obj_set_pos(ui->screen_label_16, 69, 60);
	lv_obj_set_size(ui->screen_label_16, 30, 0);

	//Write codes screen_label_12
	ui->screen_label_12 = lv_label_create(ui->screen_cont_2, NULL);
	lv_label_set_text(ui->screen_label_12, "光照 ");
	lv_label_set_long_mode(ui->screen_label_12, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_12, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_12
	static lv_style_t style_screen_label_12_main;
	lv_style_reset(&style_screen_label_12_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_12_main
	lv_style_set_radius(&style_screen_label_12_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_12_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_12_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_12_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_12_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_12_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_12_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_12_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_12_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_12_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_12_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_12_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_12, LV_LABEL_PART_MAIN, &style_screen_label_12_main);
	lv_obj_set_pos(ui->screen_label_12, 6, 120);
	lv_obj_set_size(ui->screen_label_12, 30, 0);

	//Write codes screen_img_10
	ui->screen_img_10 = lv_img_create(ui->screen_cont_2, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_10
	static lv_style_t style_screen_img_10_main;
	lv_style_reset(&style_screen_img_10_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_10_main
	lv_style_set_image_recolor(&style_screen_img_10_main, LV_STATE_DEFAULT, lv_color_make(0xf0, 0xf0, 0xf0));
	lv_style_set_image_recolor_opa(&style_screen_img_10_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_10_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_10, LV_IMG_PART_MAIN, &style_screen_img_10_main);
	lv_obj_set_pos(ui->screen_img_10, 119, 100);
	lv_obj_set_size(ui->screen_img_10, 20, 20);
	lv_obj_set_click(ui->screen_img_10, true);
	lv_img_set_src(ui->screen_img_10,&_smoke_alpha_20x20);
	lv_img_set_pivot(ui->screen_img_10, 0,0);
	lv_img_set_angle(ui->screen_img_10, 0);

	//Write codes screen_img_9
	ui->screen_img_9 = lv_img_create(ui->screen_cont_2, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_9
	static lv_style_t style_screen_img_9_main;
	lv_style_reset(&style_screen_img_9_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_9_main
	lv_style_set_image_recolor(&style_screen_img_9_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_9_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_9_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_9, LV_IMG_PART_MAIN, &style_screen_img_9_main);
	lv_obj_set_pos(ui->screen_img_9, 120, 60);
	lv_obj_set_size(ui->screen_img_9, 20, 20);
	lv_obj_set_click(ui->screen_img_9, true);
	lv_img_set_src(ui->screen_img_9,&_VOC_alpha_20x20);
	lv_img_set_pivot(ui->screen_img_9, 0,0);
	lv_img_set_angle(ui->screen_img_9, 0);

	//Write codes screen_img_8
	ui->screen_img_8 = lv_img_create(ui->screen_cont_2, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_8
	static lv_style_t style_screen_img_8_main;
	lv_style_reset(&style_screen_img_8_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_8_main
	lv_style_set_image_recolor(&style_screen_img_8_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_8_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_8_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_8, LV_IMG_PART_MAIN, &style_screen_img_8_main);
	lv_obj_set_pos(ui->screen_img_8, 120, 10);
	lv_obj_set_size(ui->screen_img_8, 25, 25);
	lv_obj_set_click(ui->screen_img_8, true);
	lv_img_set_src(ui->screen_img_8,&_CO2_alpha_25x25);
	lv_img_set_pivot(ui->screen_img_8, 0,0);
	lv_img_set_angle(ui->screen_img_8, 0);

	//Write codes screen_img_6
	ui->screen_img_6 = lv_img_create(ui->screen_cont_2, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_6
	static lv_style_t style_screen_img_6_main;
	lv_style_reset(&style_screen_img_6_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_6_main
	lv_style_set_image_recolor(&style_screen_img_6_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_6_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_6_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_6, LV_IMG_PART_MAIN, &style_screen_img_6_main);
	lv_obj_set_pos(ui->screen_img_6, 10, 55);
	lv_obj_set_size(ui->screen_img_6, 20, 20);
	lv_obj_set_click(ui->screen_img_6, true);
	lv_img_set_src(ui->screen_img_6,&_hum_alpha_20x20);
	lv_img_set_pivot(ui->screen_img_6, 0,0);
	lv_img_set_angle(ui->screen_img_6, 0);

	//Write codes screen_img_5
	ui->screen_img_5 = lv_img_create(ui->screen_cont_2, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_5
	static lv_style_t style_screen_img_5_main;
	lv_style_reset(&style_screen_img_5_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_5_main
	lv_style_set_image_recolor(&style_screen_img_5_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_5_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_5, LV_IMG_PART_MAIN, &style_screen_img_5_main);
	lv_obj_set_pos(ui->screen_img_5, 10, 10);
	lv_obj_set_size(ui->screen_img_5, 20, 20);
	lv_obj_set_click(ui->screen_img_5, true);
	lv_img_set_src(ui->screen_img_5,&_tem_alpha_20x20);
	lv_img_set_pivot(ui->screen_img_5, 0,0);
	lv_img_set_angle(ui->screen_img_5, 0);
	lv_cont_set_layout(ui->screen_cont_2, LV_LAYOUT_OFF);
	lv_cont_set_fit(ui->screen_cont_2, LV_FIT_NONE);

	//Write codes screen_cont_3
	ui->screen_cont_3 = lv_cont_create(ui->screen, NULL);

	//Write style LV_CONT_PART_MAIN for screen_cont_3
	static lv_style_t style_screen_cont_3_main;
	lv_style_reset(&style_screen_cont_3_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_cont_3_main
	lv_style_set_radius(&style_screen_cont_3_main, LV_STATE_DEFAULT, 5);
	lv_style_set_bg_color(&style_screen_cont_3_main, LV_STATE_DEFAULT, lv_color_make(0xcf, 0xed, 0xf7));
	lv_style_set_bg_grad_color(&style_screen_cont_3_main, LV_STATE_DEFAULT, lv_color_make(0xe8, 0xf5, 0xcc));
	lv_style_set_bg_grad_dir(&style_screen_cont_3_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_cont_3_main, LV_STATE_DEFAULT, 255);
	lv_style_set_border_color(&style_screen_cont_3_main, LV_STATE_DEFAULT, lv_color_make(0xa4, 0xbc, 0xf4));
	lv_style_set_border_width(&style_screen_cont_3_main, LV_STATE_DEFAULT, 3);
	lv_style_set_border_opa(&style_screen_cont_3_main, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_cont_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_cont_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_cont_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_cont_3_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_cont_3, LV_CONT_PART_MAIN, &style_screen_cont_3_main);
	lv_obj_set_pos(ui->screen_cont_3, 120, 0);
	lv_obj_set_size(ui->screen_cont_3, 200, 100);
	lv_obj_set_click(ui->screen_cont_3, false);

	//Write codes screen_img_17
	ui->screen_img_17 = lv_img_create(ui->screen_cont_3, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_17
	static lv_style_t style_screen_img_17_main;
	lv_style_reset(&style_screen_img_17_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_17_main
	lv_style_set_image_recolor(&style_screen_img_17_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_17_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_17_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_17, LV_IMG_PART_MAIN, &style_screen_img_17_main);
	lv_obj_set_pos(ui->screen_img_17, 142, 2);
	lv_obj_set_size(ui->screen_img_17, 15, 15);
	lv_obj_set_click(ui->screen_img_17, true);
	lv_img_set_src(ui->screen_img_17,&_nowifi_alpha_15x15);
	lv_img_set_pivot(ui->screen_img_17, 0,0);
	lv_img_set_angle(ui->screen_img_17, 0);

	//Write codes screen_img_14
	ui->screen_img_14 = lv_img_create(ui->screen_cont_3, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_14
	static lv_style_t style_screen_img_14_main;
	lv_style_reset(&style_screen_img_14_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_14_main
	lv_style_set_image_recolor(&style_screen_img_14_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_14_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_14_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_14, LV_IMG_PART_MAIN, &style_screen_img_14_main);
	lv_obj_set_pos(ui->screen_img_14, 175, 2);
	lv_obj_set_size(ui->screen_img_14, 15, 15);
	lv_obj_set_click(ui->screen_img_14, true);
	lv_img_set_src(ui->screen_img_14,&_battery_alpha_15x15);
	lv_img_set_pivot(ui->screen_img_14, 0,0);
	lv_img_set_angle(ui->screen_img_14, 0);

	//Write codes screen_img_13
	ui->screen_img_13 = lv_img_create(ui->screen_cont_3, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_13
	static lv_style_t style_screen_img_13_main;
	lv_style_reset(&style_screen_img_13_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_13_main
	lv_style_set_image_recolor(&style_screen_img_13_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_13_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_13_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_13, LV_IMG_PART_MAIN, &style_screen_img_13_main);
	lv_obj_set_pos(ui->screen_img_13, 160, 4);
	lv_obj_set_size(ui->screen_img_13, 10, 10);
	lv_obj_set_click(ui->screen_img_13, true);
	lv_img_set_src(ui->screen_img_13,&_WIFI_alpha_10x10);
	lv_img_set_pivot(ui->screen_img_13, 0,0);
	lv_img_set_angle(ui->screen_img_13, 0);

	//Write codes screen_label_2
	ui->screen_label_2 = lv_label_create(ui->screen_cont_3, NULL);
	lv_label_set_text(ui->screen_label_2, "时间 ");
	lv_label_set_long_mode(ui->screen_label_2, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_2, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_2
	static lv_style_t style_screen_label_2_main;
	lv_style_reset(&style_screen_label_2_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_2_main
	lv_style_set_radius(&style_screen_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_2_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_2_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_2_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_2_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_2_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_2_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_2_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_2_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_2, LV_LABEL_PART_MAIN, &style_screen_label_2_main);
	lv_obj_set_pos(ui->screen_label_2, 8, 35);
	lv_obj_set_size(ui->screen_label_2, 30, 0);

	//Write codes screen_label_4
	ui->screen_label_4 = lv_label_create(ui->screen_cont_3, NULL);
	lv_label_set_text(ui->screen_label_4, "17:10:00");
	lv_label_set_long_mode(ui->screen_label_4, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_4, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_4
	static lv_style_t style_screen_label_4_main;
	lv_style_reset(&style_screen_label_4_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_4_main
	lv_style_set_radius(&style_screen_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_4_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_4_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_4_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_4_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_4_main, LV_STATE_DEFAULT, &lv_font_simsun_30);
	lv_style_set_text_letter_space(&style_screen_label_4_main, LV_STATE_DEFAULT, 1);
	lv_style_set_pad_left(&style_screen_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_4_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_4, LV_LABEL_PART_MAIN, &style_screen_label_4_main);
	lv_obj_set_pos(ui->screen_label_4, 26, 26);
	lv_obj_set_size(ui->screen_label_4, 170, 0);

	//Write codes screen_label_3
	ui->screen_label_3 = lv_label_create(ui->screen_cont_3, NULL);
	lv_label_set_text(ui->screen_label_3, "日期 ");
	lv_label_set_long_mode(ui->screen_label_3, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_3, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_3
	static lv_style_t style_screen_label_3_main;
	lv_style_reset(&style_screen_label_3_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_3_main
	lv_style_set_radius(&style_screen_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_3_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_3_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_3_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_3_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_3_main, LV_STATE_DEFAULT, &lv_font_simsun_10);
	lv_style_set_text_letter_space(&style_screen_label_3_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_3_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_3_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_3, LV_LABEL_PART_MAIN, &style_screen_label_3_main);
	lv_obj_set_pos(ui->screen_label_3, 8, 69);
	lv_obj_set_size(ui->screen_label_3, 30, 0);

	//Write codes screen_label_5
	ui->screen_label_5 = lv_label_create(ui->screen_cont_3, NULL);
	lv_label_set_text(ui->screen_label_5, "2023/11/6");
	lv_label_set_long_mode(ui->screen_label_5, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_5, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_5
	static lv_style_t style_screen_label_5_main;
	lv_style_reset(&style_screen_label_5_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_5_main
	lv_style_set_radius(&style_screen_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_5_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_5_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_5_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_5_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_5_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_label_5_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_5_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_5_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_5, LV_LABEL_PART_MAIN, &style_screen_label_5_main);
	lv_obj_set_pos(ui->screen_label_5, 65, 67);
	lv_obj_set_size(ui->screen_label_5, 80, 0);
	lv_cont_set_layout(ui->screen_cont_3, LV_LAYOUT_OFF);
	lv_cont_set_fit(ui->screen_cont_3, LV_FIT_NONE);

	//Write codes screen_cont_4
	ui->screen_cont_4 = lv_cont_create(ui->screen, NULL);

	//Write style LV_CONT_PART_MAIN for screen_cont_4
	static lv_style_t style_screen_cont_4_main;
	lv_style_reset(&style_screen_cont_4_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_cont_4_main
	lv_style_set_radius(&style_screen_cont_4_main, LV_STATE_DEFAULT, 5);
	lv_style_set_bg_color(&style_screen_cont_4_main, LV_STATE_DEFAULT, lv_color_make(0xbf, 0xfd, 0xc1));
	lv_style_set_bg_grad_color(&style_screen_cont_4_main, LV_STATE_DEFAULT, lv_color_make(0xcf, 0xee, 0xcd));
	lv_style_set_bg_grad_dir(&style_screen_cont_4_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_cont_4_main, LV_STATE_DEFAULT, 255);
	lv_style_set_border_color(&style_screen_cont_4_main, LV_STATE_DEFAULT, lv_color_make(0xa4, 0xbc, 0xf4));
	lv_style_set_border_width(&style_screen_cont_4_main, LV_STATE_DEFAULT, 3);
	lv_style_set_border_opa(&style_screen_cont_4_main, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_cont_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_cont_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_cont_4_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_cont_4_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_cont_4, LV_CONT_PART_MAIN, &style_screen_cont_4_main);
	lv_obj_set_pos(ui->screen_cont_4, 200, 99);
	lv_obj_set_size(ui->screen_cont_4, 120, 140);
	lv_obj_set_click(ui->screen_cont_4, false);

	//Write codes screen_label_27
	ui->screen_label_27 = lv_label_create(ui->screen_cont_4, NULL);
	lv_label_set_text(ui->screen_label_27, "甲醛 ");
	lv_label_set_long_mode(ui->screen_label_27, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_27, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_27
	static lv_style_t style_screen_label_27_main;
	lv_style_reset(&style_screen_label_27_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_27_main
	lv_style_set_radius(&style_screen_label_27_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_27_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_27_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_27_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_27_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_27_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_27_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_label_27_main, LV_STATE_DEFAULT, 2);
	lv_style_set_pad_left(&style_screen_label_27_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_27_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_27_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_27_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_27, LV_LABEL_PART_MAIN, &style_screen_label_27_main);
	lv_obj_set_pos(ui->screen_label_27, 45, 61);
	lv_obj_set_size(ui->screen_label_27, 30, 0);

	//Write codes screen_label_21
	ui->screen_label_21 = lv_label_create(ui->screen_cont_4, NULL);
	lv_label_set_text(ui->screen_label_21, "低 ");
	lv_label_set_long_mode(ui->screen_label_21, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_21, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_21
	static lv_style_t style_screen_label_21_main;
	lv_style_reset(&style_screen_label_21_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_21_main
	lv_style_set_radius(&style_screen_label_21_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_21_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_21_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_21_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_21_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_21_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_21_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_label_21_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_left(&style_screen_label_21_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_21_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_21_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_21_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_21, LV_LABEL_PART_MAIN, &style_screen_label_21_main);
	lv_obj_set_pos(ui->screen_label_21, 25, 96);
	lv_obj_set_size(ui->screen_label_21, 15, 0);

	//Write codes screen_label_24
	ui->screen_label_24 = lv_label_create(ui->screen_cont_4, NULL);
	lv_label_set_text(ui->screen_label_24, "甲醛浓度低，适宜居住 ");
	lv_label_set_long_mode(ui->screen_label_24, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_24, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_24
	static lv_style_t style_screen_label_24_main;
	lv_style_reset(&style_screen_label_24_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_24_main
	lv_style_set_radius(&style_screen_label_24_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_24_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_24_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_24_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_24_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_24_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_24_main, LV_STATE_DEFAULT, &lv_font_simsun_8);
	lv_style_set_text_letter_space(&style_screen_label_24_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_left(&style_screen_label_24_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_24_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_24_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_24_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_24, LV_LABEL_PART_MAIN, &style_screen_label_24_main);
	lv_obj_set_pos(ui->screen_label_24, 9, 121);
	lv_obj_set_size(ui->screen_label_24, 100, 0);

	//Write codes screen_label_22
	ui->screen_label_22 = lv_label_create(ui->screen_cont_4, NULL);
	lv_label_set_text(ui->screen_label_22, "中 ");
	lv_label_set_long_mode(ui->screen_label_22, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_22, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_22
	static lv_style_t style_screen_label_22_main;
	lv_style_reset(&style_screen_label_22_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_22_main
	lv_style_set_radius(&style_screen_label_22_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_22_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_22_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_22_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_22_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_22_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_22_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_label_22_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_left(&style_screen_label_22_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_22_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_22_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_22_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_22, LV_LABEL_PART_MAIN, &style_screen_label_22_main);
	lv_obj_set_pos(ui->screen_label_22, 50, 96);
	lv_obj_set_size(ui->screen_label_22, 15, 0);

	//Write codes screen_label_23
	ui->screen_label_23 = lv_label_create(ui->screen_cont_4, NULL);
	lv_label_set_text(ui->screen_label_23, "高 ");
	lv_label_set_long_mode(ui->screen_label_23, LV_LABEL_LONG_BREAK);
	lv_label_set_align(ui->screen_label_23, LV_LABEL_ALIGN_CENTER);

	//Write style LV_LABEL_PART_MAIN for screen_label_23
	static lv_style_t style_screen_label_23_main;
	lv_style_reset(&style_screen_label_23_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_label_23_main
	lv_style_set_radius(&style_screen_label_23_main, LV_STATE_DEFAULT, 0);
	lv_style_set_bg_color(&style_screen_label_23_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_color(&style_screen_label_23_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_label_23_main, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_label_23_main, LV_STATE_DEFAULT, 0);
	lv_style_set_text_color(&style_screen_label_23_main, LV_STATE_DEFAULT, lv_color_make(0x00, 0x00, 0x00));
	lv_style_set_text_font(&style_screen_label_23_main, LV_STATE_DEFAULT, &lv_font_simsun_12);
	lv_style_set_text_letter_space(&style_screen_label_23_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_left(&style_screen_label_23_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_label_23_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_label_23_main, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_label_23_main, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_label_23, LV_LABEL_PART_MAIN, &style_screen_label_23_main);
	lv_obj_set_pos(ui->screen_label_23, 75, 96);
	lv_obj_set_size(ui->screen_label_23, 15, 0);

	//Write codes screen_bar_7
	ui->screen_bar_7 = lv_bar_create(ui->screen_cont_4, NULL);

	//Write style LV_BAR_PART_BG for screen_bar_7
	static lv_style_t style_screen_bar_7_bg;
	lv_style_reset(&style_screen_bar_7_bg);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_7_bg
	lv_style_set_radius(&style_screen_bar_7_bg, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_7_bg, LV_STATE_DEFAULT, lv_color_make(0xd4, 0xd7, 0xd9));
	lv_style_set_bg_grad_color(&style_screen_bar_7_bg, LV_STATE_DEFAULT, lv_color_make(0xd4, 0xd7, 0xd9));
	lv_style_set_bg_grad_dir(&style_screen_bar_7_bg, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_7_bg, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_bar_7_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_bar_7_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_bar_7_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_bar_7_bg, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_bar_7, LV_BAR_PART_BG, &style_screen_bar_7_bg);

	//Write style LV_BAR_PART_INDIC for screen_bar_7
	static lv_style_t style_screen_bar_7_indic;
	lv_style_reset(&style_screen_bar_7_indic);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_7_indic
	lv_style_set_radius(&style_screen_bar_7_indic, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_7_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_bar_7_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_dir(&style_screen_bar_7_indic, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_7_indic, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_bar_7, LV_BAR_PART_INDIC, &style_screen_bar_7_indic);
	lv_obj_set_pos(ui->screen_bar_7, 25, 81);
	lv_obj_set_size(ui->screen_bar_7, 75, 6);
	lv_bar_set_anim_time(ui->screen_bar_7,1000);
	lv_bar_set_value(ui->screen_bar_7,20,LV_ANIM_OFF);
	lv_bar_set_range(ui->screen_bar_7,0,100);

	//Write codes screen_img_12
	ui->screen_img_12 = lv_img_create(ui->screen_cont_4, NULL);

	//Write style LV_IMG_PART_MAIN for screen_img_12
	static lv_style_t style_screen_img_12_main;
	lv_style_reset(&style_screen_img_12_main);

	//Write style state: LV_STATE_DEFAULT for style_screen_img_12_main
	lv_style_set_image_recolor(&style_screen_img_12_main, LV_STATE_DEFAULT, lv_color_make(0xff, 0xff, 0xff));
	lv_style_set_image_recolor_opa(&style_screen_img_12_main, LV_STATE_DEFAULT, 0);
	lv_style_set_image_opa(&style_screen_img_12_main, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_img_12, LV_IMG_PART_MAIN, &style_screen_img_12_main);
	lv_obj_set_pos(ui->screen_img_12, 45, 32);
	lv_obj_set_size(ui->screen_img_12, 30, 30);
	lv_obj_set_click(ui->screen_img_12, true);
	lv_img_set_src(ui->screen_img_12,&_c2ho_alpha_30x30);
	lv_img_set_pivot(ui->screen_img_12, 0,0);
	lv_img_set_angle(ui->screen_img_12, 0);
	lv_cont_set_layout(ui->screen_cont_4, LV_LAYOUT_OFF);
	lv_cont_set_fit(ui->screen_cont_4, LV_FIT_NONE);

	//Write codes screen_bar_1
	ui->screen_bar_1 = lv_bar_create(ui->screen, NULL);

	//Write style LV_BAR_PART_BG for screen_bar_1
	static lv_style_t style_screen_bar_1_bg;
	lv_style_reset(&style_screen_bar_1_bg);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_1_bg
	lv_style_set_radius(&style_screen_bar_1_bg, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_1_bg, LV_STATE_DEFAULT, lv_color_make(0xc2, 0xff, 0xc4));
	lv_style_set_bg_grad_color(&style_screen_bar_1_bg, LV_STATE_DEFAULT, lv_color_make(0xb5, 0xdc, 0xf7));
	lv_style_set_bg_grad_dir(&style_screen_bar_1_bg, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_1_bg, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_bar_1_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_bar_1_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_bar_1_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_bar_1_bg, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_bar_1, LV_BAR_PART_BG, &style_screen_bar_1_bg);

	//Write style LV_BAR_PART_INDIC for screen_bar_1
	static lv_style_t style_screen_bar_1_indic;
	lv_style_reset(&style_screen_bar_1_indic);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_1_indic
	lv_style_set_radius(&style_screen_bar_1_indic, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_1_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_bar_1_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_dir(&style_screen_bar_1_indic, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_1_indic, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_bar_1, LV_BAR_PART_INDIC, &style_screen_bar_1_indic);
	lv_obj_set_pos(ui->screen_bar_1, 43, 135);
	lv_obj_set_size(ui->screen_bar_1, 50, 5);
	lv_bar_set_anim_time(ui->screen_bar_1,1000);
	lv_bar_set_value(ui->screen_bar_1,54,LV_ANIM_OFF);
	lv_bar_set_range(ui->screen_bar_1,0,100);

	//Write codes screen_bar_2
	ui->screen_bar_2 = lv_bar_create(ui->screen, NULL);

	//Write style LV_BAR_PART_BG for screen_bar_2
	static lv_style_t style_screen_bar_2_bg;
	lv_style_reset(&style_screen_bar_2_bg);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_2_bg
	lv_style_set_radius(&style_screen_bar_2_bg, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_2_bg, LV_STATE_DEFAULT, lv_color_make(0xce, 0x86, 0xfd));
	lv_style_set_bg_grad_color(&style_screen_bar_2_bg, LV_STATE_DEFAULT, lv_color_make(0xfa, 0xff, 0xb8));
	lv_style_set_bg_grad_dir(&style_screen_bar_2_bg, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_2_bg, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_bar_2_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_bar_2_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_bar_2_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_bar_2_bg, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_bar_2, LV_BAR_PART_BG, &style_screen_bar_2_bg);

	//Write style LV_BAR_PART_INDIC for screen_bar_2
	static lv_style_t style_screen_bar_2_indic;
	lv_style_reset(&style_screen_bar_2_indic);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_2_indic
	lv_style_set_radius(&style_screen_bar_2_indic, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_2_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_bar_2_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_dir(&style_screen_bar_2_indic, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_2_indic, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_bar_2, LV_BAR_PART_INDIC, &style_screen_bar_2_indic);
	lv_obj_set_pos(ui->screen_bar_2, 145, 135);
	lv_obj_set_size(ui->screen_bar_2, 50, 5);
	lv_bar_set_anim_time(ui->screen_bar_2,1000);
	lv_bar_set_value(ui->screen_bar_2,29,LV_ANIM_OFF);
	lv_bar_set_range(ui->screen_bar_2,0,100);

	//Write codes screen_bar_3
	ui->screen_bar_3 = lv_bar_create(ui->screen, NULL);

	//Write style LV_BAR_PART_BG for screen_bar_3
	static lv_style_t style_screen_bar_3_bg;
	lv_style_reset(&style_screen_bar_3_bg);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_3_bg
	lv_style_set_radius(&style_screen_bar_3_bg, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_3_bg, LV_STATE_DEFAULT, lv_color_make(0xc3, 0xf7, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_bar_3_bg, LV_STATE_DEFAULT, lv_color_make(0xb8, 0xe2, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_bar_3_bg, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_3_bg, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_bar_3_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_bar_3_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_bar_3_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_bar_3_bg, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_bar_3, LV_BAR_PART_BG, &style_screen_bar_3_bg);

	//Write style LV_BAR_PART_INDIC for screen_bar_3
	static lv_style_t style_screen_bar_3_indic;
	lv_style_reset(&style_screen_bar_3_indic);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_3_indic
	lv_style_set_radius(&style_screen_bar_3_indic, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_3_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_bar_3_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_dir(&style_screen_bar_3_indic, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_3_indic, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_bar_3, LV_BAR_PART_INDIC, &style_screen_bar_3_indic);
	lv_obj_set_pos(ui->screen_bar_3, 43, 180);
	lv_obj_set_size(ui->screen_bar_3, 50, 5);
	lv_bar_set_anim_time(ui->screen_bar_3,1000);
	lv_bar_set_value(ui->screen_bar_3,12,LV_ANIM_OFF);
	lv_bar_set_range(ui->screen_bar_3,0,100);

	//Write codes screen_bar_4
	ui->screen_bar_4 = lv_bar_create(ui->screen, NULL);

	//Write style LV_BAR_PART_BG for screen_bar_4
	static lv_style_t style_screen_bar_4_bg;
	lv_style_reset(&style_screen_bar_4_bg);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_4_bg
	lv_style_set_radius(&style_screen_bar_4_bg, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_4_bg, LV_STATE_DEFAULT, lv_color_make(0xce, 0x86, 0xfd));
	lv_style_set_bg_grad_color(&style_screen_bar_4_bg, LV_STATE_DEFAULT, lv_color_make(0xb8, 0xe2, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_bar_4_bg, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_4_bg, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_bar_4_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_bar_4_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_bar_4_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_bar_4_bg, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_bar_4, LV_BAR_PART_BG, &style_screen_bar_4_bg);

	//Write style LV_BAR_PART_INDIC for screen_bar_4
	static lv_style_t style_screen_bar_4_indic;
	lv_style_reset(&style_screen_bar_4_indic);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_4_indic
	lv_style_set_radius(&style_screen_bar_4_indic, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_4_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_bar_4_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_dir(&style_screen_bar_4_indic, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_4_indic, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_bar_4, LV_BAR_PART_INDIC, &style_screen_bar_4_indic);
	lv_obj_set_pos(ui->screen_bar_4, 43, 220);
	lv_obj_set_size(ui->screen_bar_4, 50, 5);
	lv_bar_set_anim_time(ui->screen_bar_4,1000);
	lv_bar_set_value(ui->screen_bar_4,60,LV_ANIM_OFF);
	lv_bar_set_range(ui->screen_bar_4,0,100);

	//Write codes screen_bar_5
	ui->screen_bar_5 = lv_bar_create(ui->screen, NULL);

	//Write style LV_BAR_PART_BG for screen_bar_5
	static lv_style_t style_screen_bar_5_bg;
	lv_style_reset(&style_screen_bar_5_bg);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_5_bg
	lv_style_set_radius(&style_screen_bar_5_bg, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_5_bg, LV_STATE_DEFAULT, lv_color_make(0x7c, 0x8b, 0xfd));
	lv_style_set_bg_grad_color(&style_screen_bar_5_bg, LV_STATE_DEFAULT, lv_color_make(0xb8, 0xe2, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_bar_5_bg, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_5_bg, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_bar_5_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_bar_5_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_bar_5_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_bar_5_bg, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_bar_5, LV_BAR_PART_BG, &style_screen_bar_5_bg);

	//Write style LV_BAR_PART_INDIC for screen_bar_5
	static lv_style_t style_screen_bar_5_indic;
	lv_style_reset(&style_screen_bar_5_indic);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_5_indic
	lv_style_set_radius(&style_screen_bar_5_indic, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_5_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_bar_5_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_dir(&style_screen_bar_5_indic, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_5_indic, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_bar_5, LV_BAR_PART_INDIC, &style_screen_bar_5_indic);
	lv_obj_set_pos(ui->screen_bar_5, 145, 180);
	lv_obj_set_size(ui->screen_bar_5, 50, 5);
	lv_bar_set_anim_time(ui->screen_bar_5,1000);
	lv_bar_set_value(ui->screen_bar_5,29,LV_ANIM_OFF);
	lv_bar_set_range(ui->screen_bar_5,0,100);

	//Write codes screen_bar_6
	ui->screen_bar_6 = lv_bar_create(ui->screen, NULL);

	//Write style LV_BAR_PART_BG for screen_bar_6
	static lv_style_t style_screen_bar_6_bg;
	lv_style_reset(&style_screen_bar_6_bg);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_6_bg
	lv_style_set_radius(&style_screen_bar_6_bg, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_6_bg, LV_STATE_DEFAULT, lv_color_make(0x7c, 0x8b, 0xfd));
	lv_style_set_bg_grad_color(&style_screen_bar_6_bg, LV_STATE_DEFAULT, lv_color_make(0xb8, 0xe2, 0xff));
	lv_style_set_bg_grad_dir(&style_screen_bar_6_bg, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_6_bg, LV_STATE_DEFAULT, 255);
	lv_style_set_pad_left(&style_screen_bar_6_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_right(&style_screen_bar_6_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_top(&style_screen_bar_6_bg, LV_STATE_DEFAULT, 0);
	lv_style_set_pad_bottom(&style_screen_bar_6_bg, LV_STATE_DEFAULT, 0);
	lv_obj_add_style(ui->screen_bar_6, LV_BAR_PART_BG, &style_screen_bar_6_bg);

	//Write style LV_BAR_PART_INDIC for screen_bar_6
	static lv_style_t style_screen_bar_6_indic;
	lv_style_reset(&style_screen_bar_6_indic);

	//Write style state: LV_STATE_DEFAULT for style_screen_bar_6_indic
	lv_style_set_radius(&style_screen_bar_6_indic, LV_STATE_DEFAULT, 10);
	lv_style_set_bg_color(&style_screen_bar_6_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_color(&style_screen_bar_6_indic, LV_STATE_DEFAULT, lv_color_make(0x01, 0xa2, 0xb1));
	lv_style_set_bg_grad_dir(&style_screen_bar_6_indic, LV_STATE_DEFAULT, LV_GRAD_DIR_VER);
	lv_style_set_bg_opa(&style_screen_bar_6_indic, LV_STATE_DEFAULT, 255);
	lv_obj_add_style(ui->screen_bar_6, LV_BAR_PART_INDIC, &style_screen_bar_6_indic);
	lv_obj_set_pos(ui->screen_bar_6, 145, 220);
	lv_obj_set_size(ui->screen_bar_6, 50, 5);
	lv_bar_set_anim_time(ui->screen_bar_6,1000);
	lv_bar_set_value(ui->screen_bar_6,29,LV_ANIM_OFF);
	lv_bar_set_range(ui->screen_bar_6,0,100);
}