/*
 * Copyright 2023 NXP
 * SPDX-License-Identifier: MIT
 */

#ifndef GUI_GUIDER_H
#define GUI_GUIDER_H
#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"
#include "guider_fonts.h"

typedef struct
{
	lv_obj_t *screen;
	lv_obj_t *screen_cont_1;
	lv_obj_t *screen_label_26;
	lv_obj_t *screen_img_16;
	lv_obj_t *screen_label_25;
	lv_obj_t *screen_img_15;
	lv_obj_t *screen_img_4;
	lv_obj_t *screen_img_3;
	lv_obj_t *screen_img_2;
	lv_obj_t *screen_img_1;
	lv_obj_t *screen_cont_2;
	lv_obj_t *screen_img_11;
	lv_obj_t *screen_label_6;
	lv_obj_t *screen_label_13;
	lv_obj_t *screen_label_14;
	lv_obj_t *screen_label_9;
	lv_obj_t *screen_label_10;
	lv_obj_t *screen_label_11;
	lv_obj_t *screen_label_7;
	lv_obj_t *screen_label_15;
	lv_obj_t *screen_label_17;
	lv_obj_t *screen_label_18;
	lv_obj_t *screen_label_19;
	lv_obj_t *screen_label_20;
	lv_obj_t *screen_label_16;
	lv_obj_t *screen_label_12;
	lv_obj_t *screen_img_10;
	lv_obj_t *screen_img_9;
	lv_obj_t *screen_img_8;
	lv_obj_t *screen_img_6;
	lv_obj_t *screen_img_5;
	lv_obj_t *screen_cont_3;
	lv_obj_t *screen_img_17;
	lv_obj_t *screen_img_14;
	lv_obj_t *screen_img_13;
	lv_obj_t *screen_label_2;
	lv_obj_t *screen_label_4;
	lv_obj_t *screen_label_3;
	lv_obj_t *screen_label_5;
	lv_obj_t *screen_cont_4;
	lv_obj_t *screen_label_27;
	lv_obj_t *screen_label_21;
	lv_obj_t *screen_label_24;
	lv_obj_t *screen_label_22;
	lv_obj_t *screen_label_23;
	lv_obj_t *screen_bar_7;
	lv_obj_t *screen_img_12;
	lv_obj_t *screen_bar_1;
	lv_obj_t *screen_bar_2;
	lv_obj_t *screen_bar_3;
	lv_obj_t *screen_bar_4;
	lv_obj_t *screen_bar_5;
	lv_obj_t *screen_bar_6;
}lv_ui;

void setup_ui(lv_ui *ui);
extern lv_ui guider_ui;
void setup_scr_screen(lv_ui *ui);
LV_IMG_DECLARE(_WIFI_alpha_10x10);
LV_IMG_DECLARE(_light_alpha_20x20);
LV_IMG_DECLARE(_battery_alpha_15x15);
LV_IMG_DECLARE(_smoke_alpha_20x20);
LV_IMG_DECLARE(_hum_alpha_20x20);
LV_IMG_DECLARE(_nowifi_alpha_15x15);
LV_IMG_DECLARE(_VIP5_alpha_30x10);
LV_IMG_DECLARE(_tem_alpha_20x20);
LV_IMG_DECLARE(_QQ_alpha_17x17);
LV_IMG_DECLARE(_ID_alpha_7x7);
LV_IMG_DECLARE(_CO2_alpha_25x25);
LV_IMG_DECLARE(_sun_alpha_35x35);
LV_IMG_DECLARE(_zf_alpha_20x20);
LV_IMG_DECLARE(_VOC_alpha_20x20);
LV_IMG_DECLARE(_c2ho_alpha_30x30);
LV_IMG_DECLARE(_iphone_alpha_10x10);

#ifdef __cplusplus
}
#endif
#endif