#ifndef __DEMO_H_
#define __DEMO_H_

#include "stm32f10x.h"
#include "lv_obj.h"

extern lv_obj_t * obj1;
extern lv_obj_t * par;
extern lv_obj_t * obj2;
extern lv_obj_t * scr1;
extern lv_obj_t * scr2;
extern lv_obj_t * scr3;
extern lv_obj_t * scr4;

extern lv_font_t My_Font;
extern lv_font_t Tem_Show;
extern lv_img_dsc_t ikun_se;
extern lv_img_dsc_t kun;
void lv_ex_cont_1(void);


void Demo_object1(void);
void Demo_object2(void);
void Demo_object3(void);
void Demo_object4(void);
void Demo_object5(void);
void Demo_object6(void);
void Demo_object7(void);
#endif
